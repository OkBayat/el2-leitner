# Cambridge Vocabulary for IELTS Advanced

## Unit 1 — Human nature

### Nouns

1. adolescent
2. characteristic
3. trait

### Adjectives

4. apprehensive
5. assertive
6. clumsy
7. cynical
8. desirable
9. eccentric
10. egotistical
11. gullible
12. idealised
13. inconsiderate
14. indecisive
15. self-assured
16. self-absorbed
17. self-centred
18. self-congratulatory
19. self-deprecating
20. self-important
21. tactful
22. well-adjusted
23. well-bred
24. well-brought-up
25. well-dressed

## Unit 2 — Time for a change

### Nouns

26. era
27. evolution
28. finds
29. pioneer
30. remnants
31. retrospect
32. status quo
33. transition
34. trend

### Adjectives

35. abrupt
36. bygone
37. fleeting
38. immense
39. infinitesimal
40. moderate
41. periodic
42. preceding
43. prehistoric
44. profound
45. rapid
46. topical
47. tremendous
48. turbulent

### Phrases

49. pressed for time
50. have the time of your life
51. have time on your hands
52. in next to no time
53. in the blink of an eye
54. there aren't enough hours in the day
55. time goes so fast

### Verbs

56. excavate

## Unit 3 — No man is an island

### Nouns

57. behaviour
58. demographics
59. heritage
60. interaction
61. minority
62. norm
63. peer
64. pressure
65. segment
66. standard
67. status

### Adjectives

68. anti-social
69. conservative
70. conventional
71. harmonious
72. influential
73. multicultural
74. suburban
75. unconventional

### Phrases

76. follow accepted behaviour
77. shun mainstream values

### Verbs

78. conform
79. exclude
80. flaunt
81. obey
82. skew

## Unit 4 — Scientific discovery

### Nouns

83. capsule
84. carbon dioxide
85. compound
86. consequences
87. dose
88. emissions
89. exposure
90. food chain
91. infection
92. pesticide
93. protein
94. reaction
95. side effects

### Adjectives

96. bacterial
97. contagious
98. contaminated
99. controversial
100. crucial
101. essential
102. natural
103. organic
104. petrochemicals

### Verbs

105. absorb
106. contaminate
107. release

## Unit 5 — Striving to achieve

### Nouns

108. accounting
109. apprenticeship
110. conceptualisation
111. consistency
112. establishment
113. formulation
114. hypothesis
115. inconsistency
116. insignificance
117. interpretation
118. technician
119. theorist
120. vocation

### Adjectives

121. analytical
122. blue-collar
123. conceptual
124. hypothetical
125. indicative

### Phrases

126. a process of trial and error
127. give yourself something to aim for
128. make a concerted effort
129. set yourself a goal

## Unit 6 — Powers of persuasion

### Nouns

130. billboard
131. branding
132. distributor
133. flyer
134. gimmick
135. jingle
136. manufacturer
137. marketing
138. online retailer
139. ploy
140. rebate
141. sales representative
142. slogan
143. telemarketing
144. vendor

### Adjectives

145. catchy
146. compelling
147. distracting
148. disturbing
149. infuriating
150. invasive
151. irritating
152. monetary
153. persuasive
154. promotional
155. repetitive
156. slick
157. ubiquitous
158. unavoidable

### Verbs

159. assure
160. cultivate
161. entice
162. induce
163. oblige
164. pressurise
165. reassure
166. tempt
167. urge

## Unit 7 — Ways and means

### Adjectives

168. breathtaking
169. charming
170. comfortable
171. dramatic
172. magnificent
173. memorable
174. mountainous
175. precarious
176. remote
177. rustic
178. spectacular
179. stunning

### Verbs

180. attract
181. damage
182. outweigh

## Unit 8 — State control

### Nouns

183. bureaucrat
184. civil servant
185. community
186. healthcare
187. mayor
188. member of parliament
189. military service
190. notion
191. old-age pension
192. safety net
193. social services
194. state
195. unemployment benefit

### Phrases

196. leader of the opposition
197. lose control of
198. means tested
199. social welfare
200. social well-being

### Verbs

201. miscalculate
202. misinform
203. misdiagnose
204. mismanage
205. misunderstand
206. misinterpret
207. mislead
208. misjudge
209. mistrust
210. subsidise

## Unit 9 — Natural history

### Nouns

211. burrow
212. colony
213. deforestation
214. degradation
215. demise
216. devastation
217. flooding
218. habitat
219. harm
220. herd
221. hive
222. lifespan
223. pack
224. parasite
225. prey
226. rival
227. swarm
228. threshold

### Adjectives

229. appalling
230. aquatic
231. hypocritical
232. impartial
233. irresponsible
234. nocturnal
235. outrageous
236. risky
237. venomous

### Verbs

238. flourish
239. forage
240. hibernate
241. lay
242. poach
243. thrive

## Unit 10 — Rocket science

### Nouns

244. condensation
245. debris
246. eclipse
247. evaporation
248. gravity
249. harbour
250. light year

### Adjectives

251. astronomical
252. climatic
253. colossal
254. fascinating
255. immeasurable
256. imperceptible
257. magnetic
258. minuscule
259. transient
260. vast

### Verbs

261. activate
262. burst
263. collide
264. dilute
265. dissolve
266. penetrate
267. pierce
268. reflect
269. repel
270. solidify

## Unit 11 — Progress

### Nouns

271. cyberspace
272. expense
273. fabric
274. fibre
275. foam
276. log
277. marble
278. patent
279. pillar
280. plank
281. polyester
282. prop
283. technique
284. thread
285. timber

### Adjectives

286. cutting-edge
287. futuristic

### Verbs

288. demolish
289. dye
290. innovate
291. revolve
292. rotate
293. strike

## Unit 12 — The latest thing

### Nouns

294. archive
295. acquisitiveness
296. stockpile
297. supplies

### Adjectives

298. chic
299. drab
300. mundane
301. sophisticated

### Phrases

302. a must-have item
303. a passing trend
304. all the rage
305. casual dress
306. conspicuous consumption
307. designer label
308. disposable income
309. fashion accessory
310. get rid of
311. in vogue
312. mass branding
313. personal consumption
314. spending patterns
315. the latest trend
316. traditional dress

### Verbs

317. abandon
318. conserve
319. consume
320. discard
321. dump
322. eradicate
323. hoard
324. maintain
325. preserve
326. retain

## Unit 13 — Urban jungle

### Nouns

327. concrete jungle
328. employment opportunities
329. garbage collection
330. high-rise building
331. housing estate
332. inner-city slum
333. noise pollution
334. outer suburbs
335. sewage system
336. traffic congestion
337. urban sprawl

### Adjectives

338. frantic
339. high-rise
340. isolated
341. overpopulated
342. migrate
343. settle
344. tranquil

## Unit 14 — Tackling issues

### Nouns

345. catastrophe
346. cloning
347. controversy
348. crisis
349. dilemma
350. disaster
351. hurdle
352. obstacle
353. predicament
354. setback

### Adjectives

355. catastrophic
356. daunting
357. disastrous
358. insurmountable
359. ongoing
360. pervasive
361. problematic

### Phrases

362. do more harm than good
363. dwell on
364. energy crisis
365. gain insight into
366. genetically modified food
367. take stock

### Verbs

368. aggravate
369. alleviate
370. arise
371. exacerbate
372. hinder
373. ignore
374. improve
375. mitigate
376. rectify
377. resolve

## Unit 15 — This Earth

### Nouns

378. acid rain
379. aftershock
380. agriculture
381. cattle
382. coast
383. desalination
384. draft
385. erosion
386. fungus
387. herbivore
388. lava
389. petal
390. productivity
391. puddle
392. reservoir
393. shore
394. species
395. stem
396. tide
397. tremor

### Adjectives

398. current
399. dense
400. freezing
401. heavy
402. long-term
403. native
404. resistant
405. severe
406. torrential
407. tropical

### Phrases

408. a storm in a teacup
409. be snowed under
410. every cloud has a silver lining
411. in the cold light of day
412. know which way the wind is blowing
413. not have the foggiest idea
414. the calm before the storm
415. not a cloud in the sky
416. vicious circle
417. weather the storm

### Verbs

418. breed
419. flow
420. sow

## Unit 16 — Energy efficient

### Nouns

421. biofuel
422. carbon footprint
423. consumption
424. fumes
425. greenhouse gas
426. mining
427. natural resources
428. precious metal
429. scale
430. wind farm

### Adjectives

431. carbon neutral
432. eco-friendly
433. rechargeable
434. recyclable
435. renewable
436. precious
437. sustainable
438. unleaded

### Verbs

439. capture
440. curb
441. emit
442. exhaust
443. harness

## Unit 17 — Getting down to business

### Nouns

444. assets
445. bankruptcy
446. bottom line
447. budget
448. client
449. credit rating
450. cutback
451. earnings
452. equity
453. household name
454. luxury goods

### Adjectives

455. bankrupt
456. hands-on
457. managerial

### Phrases

458. calculated risk
459. chair a meeting
460. golden opportunity
461. keep track of
462. make a name for yourself
463. win-win situation

### Verbs

464. amalgamate

## Unit 18 — Law enforcement

### Nouns

465. capital punishment
466. community service
467. life sentence
468. mugging
469. offence
470. organised crime
471. peer pressure
472. petty crime
473. robbery
474. vandalism
475. violence

### Adjectives

476. hostile
477. lenient

### Phrases

478. accept the consequences of
479. accuse someone of
480. arrest someone for
481. be (held) responsible for
482. be a victim of
483. convicted criminal
484. criminal activity
485. criminal offence
486. criminal record
487. hardened criminal
488. juvenile crime
489. underlying causes

### Verbs

490. jail
491. punish

## Unit 19 — The media

### Nouns

492. bias
493. broadcaster
494. episode
495. headline
496. paparazzi
497. press
498. viewer

### Adjectives

499. biased
500. eminent
501. high-profile
502. prejudiced
503. prominent
504. subjective
505. world-famous

### Phrases

506. become famous overnight
507. chief claim to fame
508. in the public eye
509. instant celebrities
510. making headlines
511. media attention
512. new-found fame
513. tabloid press

### Verbs

514. assert
515. broadcast
516. contend
517. gossip
518. indicate
519. speculate

## Unit 20 — A matter of taste

### Nouns

520. animation
521. culture
522. drama
523. echo
524. engraving
525. fiction
526. imagination
527. inspiration

### Adjectives

528. abominable
529. abysmal
530. dismal
531. fictional
532. figurative
533. hilarious
534. inspirational
535. petrified
536. spine-chilling
537. talented
538. tedious
539. terrified
540. terrifying
541. thrilling

### Phrases

542. a matter of taste
543. acquire a taste for
544. be in bad taste
545. compose a song
546. have diverse tastes
547. share the same taste
