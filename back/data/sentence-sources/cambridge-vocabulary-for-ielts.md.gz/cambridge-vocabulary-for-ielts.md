# Cambridge Vocabulary for IELTS

## Unit 1 — Growing up

### Nouns

1. adolescence
2. adulthood
3. bond
4. brotherhood
5. character
6. childhood
7. conflict
8. connection
9. fatherhood
10. friendship
11. instinct
12. interaction
13. motherhood
14. nature
15. parent
16. relation
17. relationship (between/with)
18. relative
19. resemblance
20. rivalry
21. sibling
22. teenager
23. temperament
24. ties
25. upbringing

### Compound nouns

26. active role
27. extended family
28. family gathering
29. immediate family
30. maternal instinct
31. sibling rivalry
32. stable upbringing
33. striking resemblance

### Adjectives

34. close
35. close-knit
36. maternal
37. parental
38. rewarding
39. stable

### Verbs

40. accommodate
41. adopt
42. break down
43. develop
44. endure
45. establish
46. have sth in common
47. inherit
48. interact
49. nurture
50. play a role
51. relate (to)

## Unit 2 — Mental and physical development

### Nouns

52. ability
53. adolescent
54. behaviour
55. concept
56. consequence
57. gesture
58. growth
59. height
60. imagination
61. infancy
62. infant
63. knowledge
64. maturity
65. memory
66. milestone
67. mind
68. peers
69. period
70. phase
71. rate
72. reminder
73. social skills
74. skill
75. stage
76. toddler
77. transition

### Adjectives

78. abstract
79. cognitive
80. clumsy
81. fond
82. fully-grown
83. immature
84. independent
85. irresponsible
86. mature
87. patient
88. rebellious
89. significant
90. tolerant

### Verbs

91. acquire
92. grow
93. imitate
94. look back
95. master
96. remember
97. remind
98. reminisce
99. throw a tantrum
100. visualise

### Adverbs

101. typically

### Phrases

102. bear in mind
103. broaden the mind
104. have something in mind
105. have something on your mind
106. it slipped my mind
107. keep an open mind
108. my mind went blank
109. put your mind at ease

## Unit 3 — Keeping fit

### Nouns

110. allergy
111. anxiety
112. appetite
113. artery
114. asset
115. benefit
116. cravings
117. depression
118. diagnosis
119. diet
120. dietician
121. disease
122. (eating) disorder
123. exercise
124. factor
125. fast food
126. fat
127. harm
128. health
129. heart attack
130. infection
131. ingredients
132. insomnia
133. intake
134. junk food
135. muscle
136. nutrient
137. nutrition
138. obesity
139. onset
140. portion
141. risk
142. serving
143. stress
144. stroke
145. treatment
146. therapy
147. variety
148. weight

### Adjectives

149. acute
150. allergic
151. alternate
152. brisk
153. chronic
154. harmful
155. healthy
156. infectious
157. moderate
158. obese
159. overweight
160. persistent
161. regular
162. vital

### Verbs

163. avoid
164. counteract
165. curb
166. cure
167. diminish
168. disrupt
169. eliminate
170. maintain
171. overdo
172. overeat
173. prevent
174. recommend
175. recover
176. reduce
177. skip
178. stimulate
179. trigger

## Unit 4 — Lifestyles

### Nouns

180. activity
181. aspect
182. attitude
183. (achieve a) balance
184. competition
185. creativity
186. daily routine
187. desire
188. disappointment
189. experience
190. fulfillment
191. goal
192. hobby
193. insight
194. leisure
195. lifestyle
196. optimist
197. outlook
198. opportunity
199. personality
200. pessimist
201. priority
202. pressure
203. realist
204. risk-taker
205. self-expression
206. sense

### Adjectives

207. active
208. bored
209. confused
210. dissatisfied
211. intense
212. materialistic
213. negative
214. outdoor
215. positive
216. recreational
217. successful

### Verbs

218. achieve (a goal)
219. appeal
220. attract
221. choose
222. express
223. enjoy
224. fulfil
225. improve
226. motivate
227. participate
228. regret
229. relax
230. satisfy

### Verb phrases

231. lead a happy life
232. live life on the edge
233. live life to the full
234. make a choice
235. make a decision
236. make a living
237. meet a need
238. miss (an opportunity)
239. put pressure on
240. set (a goal)
241. take part (in)
242. work hard for a living

### Phrases

243. all walks of life
244. cost of living
245. lifelong ambition
246. living expenses
247. once in a lifetime opportunity
248. standard of living
249. way of life

## Unit 5 — Student life

### Nouns

250. assignment
251. college
252. controversy
253. curriculum
254. dissertation
255. education
256. exam
257. field (of study)
258. findings
259. funding
260. grade
261. graduation
262. grant
263. high school
264. homework
265. junior school
266. kindergarten
267. learning disorder
268. lecturer
269. library
270. limits
271. Masters
272. nursery
273. PhD
274. primary school
275. program
276. project
277. research
278. resources
279. results
280. scholarship
281. scope
282. secondary school
283. sources
284. syllabus
285. task
286. theory
287. thesis
288. tutor
289. topic
290. university

### Adjectives

291. academic
292. eligible
293. mixed
294. postgraduate
295. relevant
296. senior
297. single-sex
298. studious
299. work-related

### Verbs

300. adopt (an approach)
301. analyse
302. conduct
303. concentrate
304. consider
305. find out
306. graduate
307. learn (about)
308. organise
309. overcome
310. review
311. revise
312. struggle
313. take (a course)

### Adverbs

314. relatively

## Unit 6 — Effective communication

### Nouns

315. accuracy
316. communication
317. conjecture
318. dialect
319. fluency
320. hesitation
321. language
322. language barrier
323. linguist
324. linguistics
325. means of communication
326. mother tongue
327. native speaker
328. pronunciation
329. sign language
330. vocabulary

### Adjectives

331. incoherent
332. inherent
333. sophisticated
334. spontaneous

### Verbs

335. clarify
336. communicate
337. comprehend
338. conclude
339. confirm
340. converse
341. define
342. demonstrate
343. distinguish
344. emerge
345. evolve
346. explain
347. illustrate
348. imply
349. indicate
350. pronounce
351. recall
352. refer (to)
353. signify
354. state
355. stutter
356. suggest
357. translate

### Idioms

358. there is something to be said for
359. needless to say
360. have a say
361. when all is said and done
362. having said that
363. to say the least
364. you can say that again!
365. that is to say

## Unit 7 — On the move

### Nouns

366. accommodation
367. attraction
368. community
369. countryside
370. destination
371. eco-tourism
372. effect
373. facilities
374. identification
375. inhabitant
376. itinerary
377. journey
378. landscape
379. luggage
380. peak
381. tourism
382. tourist
383. transport
384. travel
385. travelling
386. trend
387. trip
388. village

### Adjectives

389. adventurous
390. budget
391. breathtaking
392. coastal
393. cosmopolitan
394. diverse
395. flexible
396. foreign
397. local
398. luxurious
399. mountainous
400. peaceful
401. picturesque
402. polluted
403. quaint
404. remote
405. rough
406. rural
407. scenic
408. stunning
409. tough
410. traditional
411. unspoilt
412. urban

### Verbs

413. affect
414. fluctuate

## Unit 8 — Through the ages

### Nouns

415. age
416. archaeologist
417. century
418. decade
419. era
420. evidence
421. excavation
422. generation
423. the Middle Ages
424. millennia
425. pioneer
426. timeline

### Adjectives

427. ancient
428. chronological
429. consecutive
430. historical
431. imminent
432. middle-aged
433. nostalgic
434. prehistoric
435. prior (to)
436. punctual
437. time-consuming

### Verbs

438. erode
439. infer
440. predate
441. span

### Phrases

442. in time
443. lose track of time
444. on time
445. save time
446. spend time
447. take so long
448. the right time

### Adverbs

449. chronologically
450. formerly
451. previously
452. subsequently

## Unit 9 — The natural world

### Nouns

453. agriculture
454. animal kingdom
455. burrow
456. climate
457. crop(s)
458. decline
459. den
460. disaster
461. ecological balance
462. ecology
463. evolution
464. extinction
465. fauna
466. flora
467. genetics
468. habitat
469. human nature
470. insect
471. Mother Nature
472. pesticides
473. predator
474. prey
475. repercussions
476. scent
477. species
478. soil
479. vegetation
480. vermin
481. weed

### Adjectives

482. arid
483. catastrophic
484. disastrous
485. domesticated
486. endangered
487. extinct
488. genetically-modified
489. introduced
490. native
491. natural
492. resistant
493. semi-arid
494. tropical
495. vulnerable
496. wild

### Verbs

497. adapt
498. combat
499. cultivate
500. eradicate
501. hibernate
502. tolerate

## Unit 10 — Reaching for the skies

### Nouns

503. asteroid
504. astronaut
505. atmosphere
506. cosmos
507. crater
508. debris
509. Earth
510. exploration
511. explorer
512. galaxy
513. gas
514. gravity
515. horizon
516. launch
517. meteor
518. moon
519. ocean
520. orbit
521. outer space
522. planet
523. radiation
524. rocket
525. satellite
526. simulator
527. solar system
528. space
529. spacecraft
530. space shuttle
531. space station
532. surface
533. universe
534. weightlessness

### Adjectives

535. commercial
536. cosmic
537. extreme
538. gravitational
539. horizontal
540. inevitable
541. lunar
542. meteoric
543. outer
544. solar
545. terrestrial
546. toxic
547. uninhabitable
548. universal
549. unmanned

### Verbs

550. acclimatise
551. colonise
552. explore
553. float
554. propel
555. rotate
556. sustain
557. simulate
558. undergo

## Unit 11 — Design and innovation

### Nouns

559. balcony
560. brick
561. building
562. ceiling
563. concrete
564. construction
565. cottage
566. design
567. device
568. elevator
569. engineering
570. frame
571. gadget
572. housing
573. innovation
574. invention
575. landmark
576. lift shaft
577. occupant
578. platform
579. quarry
580. residence
581. skyscraper
582. staircase
583. steel
584. storage
585. structure
586. tension
587. timber

### Adjectives

588. airy
589. conventional
590. cosy
591. cramped
592. curved
593. disposable
594. domestic
595. exterior
596. functional
597. futuristic
598. high-rise
599. innovative
600. internal
601. mass-produced
602. modern
603. multi-storey
604. old-fashioned
605. ornate
606. prefabricated
607. single-storey
608. spacious
609. state-of-the-art
610. two-storey
611. typical
612. ultra-modern

### Verbs

613. activate
614. automate
615. build
616. condemn
617. construct
618. decorate
619. demolish
620. devise
621. haul
622. hoist
623. invent
624. occupy
625. reconstruct
626. renovate
627. support

## Unit 12 — Information technology

### Nouns

628. automatic pilot
629. computerisation
630. data
631. function
632. the Internet
633. keyboard
634. keypad
635. laptop (computer)
636. the latest
637. monitor
638. patent
639. prototype
640. remote control
641. silicon chip
642. technology
643. telecommunications
644. vision
645. wireless connection

### Adjectives

646. compact
647. computerised
648. cutting-edge
649. cyber
650. dated
651. digital
652. labour-saving
653. portable
654. up-to-date
655. user-friendly
656. virtual

### Verbs

657. access
658. connect
659. download
660. display
661. envisage
662. operate
663. revolutionise
664. scroll
665. speculate
666. store
667. surpass

### Adverbs

668. automatically

## Unit 13 — The modern world

### Nouns

669. brand
670. culture
671. cycle
672. demographics
673. development
674. diversity
675. globalisation
676. hindsight
677. icon
678. identity
679. implication
680. impact
681. increase
682. influence
683. industry
684. isolation
685. joint venture
686. (have a) monopoly
687. market
688. modernisation
689. multiculturalism
690. percentage
691. population
692. prediction
693. projection
694. proportion
695. statistics

### Adjectives

696. ageing
697. current
698. demographic
699. elderly
700. ethnic
701. exotic
702. global
703. long-term
704. mid-term
705. multicultural
706. productive
707. sceptical
708. short-term
709. subsequent
710. wealthy
711. worldwide

### Verbs

712. compound
713. contribute
714. dominate
715. dwindle
716. merge
717. migrate

## Unit 14 — Urbanisation

### Nouns

718. challenge
719. compromise
720. difficulty
721. dilemma
722. infrastructure
723. issue
724. megacity
725. migrant
726. obstacle
727. overpopulation
728. poverty
729. resolution
730. setback
731. slum
732. solution
733. tolerance
734. traffic
735. urbanisation

### Adjectives

736. adequate
737. basic
738. booming
739. crowded
740. decent
741. developing
742. double-edged
743. isolated
744. one-sided
745. long-sighted
746. overpriced
747. overworked
748. pressing
749. short-sighted
750. staggering

### Verbs

751. address
752. adjust
753. aggravate
754. cause
755. compete
756. deal with
757. deteriorate
758. enhance
759. exacerbate
760. exclude
761. face
762. flourish
763. identify
764. include
765. linger
766. modify
767. present
768. raise
769. reform
770. regulate
771. remedy
772. resolve
773. tackle
774. transform
775. worsen

### Verb phrases

776. find a solution
777. overcome a difficulty
778. reach/find a compromise
779. remedy a situation
780. resolve an issue

## Unit 15 — The green revolution

### Nouns

781. acid rain
782. biodiversity
783. climate change
784. contamination
785. deforestation
786. disposal
787. drought
788. ecosystem
789. emission
790. the environment
791. erosion
792. exhaust (fumes)
793. fertilizer
794. flood
795. food chain
796. fumes
797. greenhouse gases
798. pollutant
799. pollution
800. process
801. refuse
802. strain
803. threat
804. waste

### Adjectives

805. achievable
806. advantageous
807. at risk
808. beneficial
809. conceivable
810. contaminated
811. devastating
812. doubtful
813. environmental
814. environmentally friendly
815. feasible
816. fruitless
817. futile
818. immune
819. impracticable
820. improbable
821. in danger (of)
822. insoluble
823. irreparable
824. irreplaceable
825. irreversible
826. liable
827. life-threatening
828. pervasive
829. pointless
830. pristine
831. questionable
832. recyclable
833. sustainable
834. taxing
835. unattainable
836. unlikely
837. unprecedented
838. useless
839. viable
840. worthwhile

### Verbs

841. confront
842. contaminate
843. dispose of
844. dump
845. threaten

### Adverbs

846. inexorably
847. inevitably

## Unit 16 — The energy crisis

### Nouns

848. balance
849. biofuel
850. carbon
851. carbon dioxide
852. crisis
853. electricity
854. emissions
855. exhaust
856. fossil fuel
857. fuel
858. greenhouse gas
859. hybrid
860. hydrogen
861. petrol
862. turbine
863. vehicle

### Adjectives

864. alternative
865. critical
866. drastic
867. eco-friendly
868. efficient
869. effective
870. nuclear
871. rechargeable
872. renewable
873. unleaded (petrol)

### Verbs

874. absorb
875. conserve
876. consume
877. convert
878. counter
879. deplete
880. discharge
881. emit
882. expend
883. limit
884. outweigh
885. preserve
886. retain

## Unit 17 — Talking business

### Nouns

887. advertisement
888. advertising
889. boss
890. campaign
891. candidate
892. career
893. clerk
894. client
895. colleague
896. company
897. consumer
898. credibility
899. customer
900. earnings
901. employee
902. employer
903. employment
904. goods
905. income
906. interview
907. job
908. job satisfaction
909. labourer
910. management
911. manual work
912. marketing
913. meeting
914. money
915. niche
916. occupation
917. office
918. overtime
919. packaging
920. pay
921. perk
922. product
923. profession
924. prospects
925. qualifications
926. retirement
927. salary
928. shares
929. shift work
930. skills
931. staff
932. supervisor
933. takeover
934. target
935. trade
936. unemployment
937. wages
938. workforce
939. workplace

### Adjectives

940. casual
941. demanding
942. economic
943. economical
944. exhausting
945. hospitality
946. monotonous
947. part-time
948. retail
949. redundant
950. unemployed
951. unskilled

### Verbs

952. apply
953. earn
954. endorse
955. invest (in)
956. persuade
957. to be promoted
958. request
959. retire

## Unit 18 — The law

### Nouns

960. actions
961. arson
962. authority
963. burglary
964. consequences
965. convict
966. crime
967. crime rate
968. criminal
969. deterrent
970. fine
971. fraud
972. imprisonment
973. inequality
974. intent
975. intrusion
976. judge
977. jury
978. kidnapping
979. lawyer
980. motive
981. murder
982. offence
983. pickpocketing
984. prevention
985. prison
986. prisoner
987. property crime
988. prosecutor
989. protection
990. punishment
991. recklessness
992. smuggling
993. social system
994. swearing
995. the accused
996. toxic waste
997. vandalism
998. victim
999. violation

### Adjectives

1000. drug-related
1001. evil
1002. guilty
1003. harsh
1004. innocent
1005. intentional
1006. law-abiding
1007. non-violent
1008. offensive
1009. on trial
1010. petty (crime)
1011. punishable
1012. random
1013. strict
1014. unintentional
1015. victimless

### Verbs

1016. abide (by)
1017. abolish
1018. deter
1019. enforce
1020. imprison
1021. obey
1022. offend
1023. perpetrate
1024. protect
1025. prove
1026. punish
1027. resent
1028. respect
1029. violate

### Verb phrases

1030. accept the consequences
1031. commit a crime
1032. convict a criminal
1033. impose a fine
1034. pass a law
1035. solve a crime

## Unit 19 — The media

### Nouns

1036. author
1037. bias
1038. censorship
1039. current affairs
1040. editor
1041. exposé
1042. exposure
1043. fame
1044. free press
1045. ideology
1046. investigation
1047. journal
1048. journalism
1049. mass media
1050. media
1051. network
1052. the news
1053. newspaper
1054. newsstand
1055. opinion
1056. paparazzi
1057. press
1058. privacy
1059. publication
1060. publicity
1061. publisher
1062. relevance
1063. safeguard
1064. source
1065. speculation
1066. tabloid
1067. the Web

### Adjectives

1068. artificial
1069. attention-grabbing
1070. biased
1071. celebrity
1072. controversial
1073. distorted
1074. entertaining
1075. factual
1076. informative
1077. intrusive
1078. investigative
1079. mainstream
1080. realistic
1081. sensationalist
1082. superficial
1083. unbiased
1084. well-informed

### Verbs

1085. broadcast
1086. censor
1087. control
1088. exploit
1089. expose
1090. inform
1091. intrude
1092. invade
1093. investigate
1094. publicize
1095. publish
1096. report
1097. verify

## Unit 20 — The arts

### Nouns

1098. actor
1099. actress
1100. aesthetics
1101. appreciation
1102. artefact
1103. artist
1104. audience
1105. ballerina
1106. ballet
1107. carving
1108. conception
1109. concert
1110. crafts
1111. creation
1112. emotion
1113. exhibition
1114. expression
1115. festival
1116. gallery
1117. image
1118. inspiration
1119. intimacy
1120. literature
1121. mood
1122. musician
1123. opera
1124. orchestra
1125. painting
1126. performance
1127. the performing arts
1128. play
1129. portrait
1130. reflection
1131. response
1132. sculptor
1133. sculpture
1134. stimulus
1135. style
1136. taste
1137. theatre
1138. theme
1139. venue
1140. works
1141. writer

### Adjectives

1142. accomplished
1143. aesthetic
1144. burgeoning
1145. classical
1146. creative
1147. cultural
1148. distracting
1149. eclectic
1150. electric
1151. emotional
1152. fundamental
1153. imaginative
1154. influential
1155. inspirational
1156. interactive
1157. literary
1158. live
1159. magical
1160. mundane
1161. passionate
1162. popular
1163. prominent
1164. relaxing
1165. stimulating
1166. visual
1167. vivid

### Verbs

1168. choreograph
1169. create
1170. depict
1171. enrich
1172. escape
1173. imagine
1174. inspire
1175. perform
1176. provoke
1177. transcend
