## File 1

### 1A Eating in and out
1. salmon
2. shrimp
3. squid
4. tuna
5. lamb
6. avocado
7. beet
8. cabbage
9. cucumber
10. eggplant
11. zucchini
12. baked
13. boiled
14. fried
15. grilled
16. roasted
17. steamed
18. ready-made food
19. take-out food
20. spicy
21. allergic
22. intolerant
23. cut down on
24. cut out

### 1B Modern families
1. stepmother
2. brother-in-law
3. stepsister
4. half-sister
5. adopted child
6. only child
7. siblings
8. immediate family
9. extended family
10. single-parent family
11. affectionate
12. ambitious
13. anxious
14. bossy
15. charming
16. competitive
17. imaginative
18. independent
19. insecure
20. mature
21. moody
22. rebellious
23. reliable
24. self-confident
25. sensible
26. sensitive
27. sociable
28. spoiled
29. stubborn
30. sympathetic

### Practical English 1 — Meeting the parents
1. You're kidding
2. I don't believe it
3. How fantastic
4. That's great news
5. What a pity
6. Never mind

## File 2

### 2A Spending money
1. inherit
2. save money
3. lend
4. borrow
5. waste money
6. afford
7. charge
8. owe
9. invest
10. earn
11. be worth
12. raise money
13. spend money on
14. get into debt
15. bill
16. budget
17. contactless payment
18. insurance
19. loan
20. mortgage
21. salary
22. tax
23. pay back
24. live on
25. bargain

### 2B Changing lives
1. charity
2. volunteer
3. sponsor
4. orphan
5. malnutrition
6. community
7. challenge
8. achievement
9. confidence
10. exhausted
11. furious
12. terrified
13. fascinating
14. starving
15. enormous
16. boiling
17. filthy
18. delighted
19. hilarious

## File 3

### 3A Survive the drive
1. freeway
2. platform
3. scooter
4. subway
5. van
6. bicycle lane
7. car crash
8. gas station
9. parking ticket
10. pedestrian zone
11. rush hour
12. speed camera
13. speed limit
14. traffic jam
15. seat belt
16. set off
17. pick up
18. drop off
19. end up
20. run out of gas
21. get stuck
22. get around
23. public transportation
24. directions

### 3B Men, women, and children
1. apologize to someone for
2. argue with someone about
3. arrive in
4. arrive at
5. ask for
6. belong to
7. choose between
8. depend on
9. laugh at
10. look forward to
11. pay for
12. remind someone of
13. talk to someone about
14. afraid of
15. angry with
16. close to
17. different from
18. excited about
19. famous for
20. fed up with
21. fond of
22. good at
23. interested in
24. proud of
25. worried about

### Practical English 2 — A difficult celebrity
1. in my opinion
2. to be honest
3. if you ask me
4. what do you think
5. I agree with you
6. I disagree with you

## File 4

### 4A Bad manners
1. dial a number
2. text someone
3. hang up
4. ringtone
5. call back
6. leave a message
7. voicemail
8. the line is busy
9. swipe through
10. go off
11. helpline
12. put someone on hold
13. get cut off
14. phone network
15. monthly contract
16. pay as you go
17. reception
18. fine
19. ban
20. appropriate
21. inconsiderate
22. recline
23. give up your seat
24. etiquette

### 4B Yes, I can!
1. be able to
2. give up
3. master a skill
4. focused practice
5. beginner
6. make progress
7. frustrated
8. annoyed
9. annoying
10. depressed
11. depressing
12. amazed
13. amazing
14. disappointed
15. disappointing
16. embarrassed
17. embarrassing
18. frightened
19. frightening
20. boring

## File 5

### 5A Sporting superstitions
1. captain
2. coach
3. referee
4. umpire
5. spectator
6. crowd
7. stadium
8. court
9. field
10. track
11. golf course
12. ski slope
13. beat
14. tie
15. train
16. get injured
17. get in shape
18. score a goal
19. warm up
20. work out
21. send off
22. knock out
23. medal
24. trophy
25. fair play
26. cheat
27. superstition
28. lucky charm

### 5B The way we met
1. classmate
2. close friend
3. colleague
4. couple
5. ex
6. fiancé
7. fiancée
8. partner
9. roommate
10. get to know
11. become friends
12. have something in common
13. fall in love
14. go out together
15. be together
16. break up
17. split up
18. lose touch
19. get in touch
20. get along
21. propose
22. get married
23. keep in touch
24. relationship
25. friendship
26. engaged

### Practical English 3 — Old friends
1. Do you mind if
2. Would you mind
3. Could you do me a favor
4. Could you pass
5. Do you think you could
6. Not at all

## File 6

### 6A Behind the scenes
1. action movie
2. animated movie
3. comedy
4. drama
5. horror movie
6. musical
7. romantic comedy
8. science fiction movie
9. thriller
10. audience
11. cast
12. critic
13. extra
14. plot
15. review
16. scene
17. script
18. sequel
19. soundtrack
20. special effects
21. subtitles
22. trailer
23. be based on
24. be set in
25. be directed by
26. play the part of
27. shoot on location
28. dubbed

### 6B Every picture tells a story
1. chin
2. shoulders
3. stomach
4. thumb
5. toes
6. tongue
7. bite
8. clap
9. nod
10. point
11. stare
12. whistle
13. charisma
14. make eye contact
15. hand gesture
16. cross your arms
17. shake hands
18. give a thumbs up
19. body language
20. close-up

## File 7

### 7A Live and learn
1. preschool
2. elementary school
3. middle school
4. high school
5. kindergarten
6. grade
7. semester
8. public school
9. private school
10. college
11. graduate
12. university
13. boarding school
14. primary school
15. secondary school
16. discipline
17. be allowed to
18. be punished
19. be suspended
20. misbehave
21. cheat on an exam
22. take an exam
23. pass an exam
24. fail an exam
25. degree
26. apply to college
27. admission
28. extracurricular activity
29. apprenticeship

### 7B The hotel of Mom and Dad
1. outskirts
2. suburb
3. attic
4. balcony
5. basement
6. chimney
7. entrance
8. first floor
9. gate
10. patio
11. roof
12. top floor
13. ceiling
14. fireplace
15. cabin
16. cozy
17. spacious
18. move out
19. live on your own
20. rent
21. housework
22. household
23. stain
24. laundry
25. home-cooked food

### Practical English 4 — Boys' night out
1. What shall we do
2. Let's
3. Why don't we
4. We could
5. What about
6. How about
7. Shall we

## File 8

### 8A The right job for you
1. apply for a job
2. be fired
3. be downsized
4. get promoted
5. resign
6. retire
7. run a business
8. set up a business
9. work overtime
10. work shifts
11. take a training course
12. freelance
13. part-time
14. full-time
15. self-employed
16. temporary
17. permanent
18. unemployed
19. qualification
20. experience
21. résumé
22. job interview
23. employer
24. employee
25. promotion
26. application
27. responsible for
28. in charge of
29. entrepreneur
30. profit

### 8B Have a nice day!
1. salesperson
2. customer
3. receipt
4. refund
5. discount
6. chain store
7. department store
8. fitting room
9. try on
10. fit
11. suit
12. shopping mall
13. customer service
14. complain
15. complaint
16. compensation
17. payment
18. delivery
19. exchange
20. return
21. in stock
22. out of stock
23. service
24. choice
25. improvement
26. explanation
27. go viral

## File 9

### 9A Lucky encounters
1. lucky
2. unlucky
3. fortunately
4. unfortunately
5. comfortable
6. uncomfortable
7. patient
8. impatient
9. careful
10. careless
11. opportunity
12. chance
13. intuition
14. optimistic
15. pessimistic
16. keep going
17. by chance
18. stranger
19. in trouble
20. grateful
21. humiliated
22. devastated
23. relieved

### 9B Digital detox
1. adaptor
2. charger
3. flash drive
4. keyboard
5. remote control
6. router
7. speaker
8. switch
9. mouse
10. outlet
11. plug
12. USB cable
13. headphones
14. unplug
15. plug in
16. switch on
17. switch off
18. turn up
19. turn down
20. set an alarm
21. install
22. update
23. delete
24. digital detox
25. cell phone coverage
26. unfollow
27. unsubscribe
28. password manager
29. inbox
30. wallpaper
31. hard drive
32. addicted to
33. distracted by

### Practical English 5 — Unexpected events
1. Could you tell me
2. Do you know if
3. I'd like to know
4. I wonder if
5. I wonder whether
6. Can you tell me

## File 10

### 10A Idols and icons
1. influential
2. icon
3. admire
4. landmark
5. iconic
6. breakthrough
7. recognition
8. publication
9. worldwide
10. self-taught
11. career
12. award
13. author
14. novelist
15. architect
16. designer
17. activist
18. civil rights
19. campaign for
20. equality
21. memorable
22. classic
23. public figure
24. biography

### 10B And the murderer is
1. detective
2. evidence
3. murder
4. murderer
5. prove
6. solve
7. suspect
8. victim
9. witness
10. crime
11. investigate
12. arrest
13. guilty
14. alibi
15. identify
16. credible
17. conclusive evidence
18. theory
19. case
20. mystery
21. commit a crime
22. police officer
23. headquarters
24. analysis
25. claim
26. reliable evidence
27. innocent
